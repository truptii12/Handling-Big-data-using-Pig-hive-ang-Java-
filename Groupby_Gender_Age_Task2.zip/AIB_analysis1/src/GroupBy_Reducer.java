import java.io.IOException;

import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;


public class GroupBy_Reducer extends
		Reducer<RentTrans, org.apache.hadoop.io.IntWritable, Text, NullWritable> {

	public void reduce(Text key, Iterable<Text> values, Context context)
			throws IOException, InterruptedException {
	
		
		System.out.println("Reducing ...");
		 context.write(key, NullWritable.get());
		 
		System.out.println("Reducing Done");
		 
	}

}
