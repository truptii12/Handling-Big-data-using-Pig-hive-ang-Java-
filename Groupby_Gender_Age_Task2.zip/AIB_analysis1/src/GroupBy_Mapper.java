import java.io.IOException;
import java.util.Arrays;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;
//import org.techmytalk.groupby.GroupMR.Country;


public class GroupBy_Mapper extends Mapper<LongWritable, Text, RentTrans, IntWritable> {
	
	RentTrans rentTrans1 = new RentTrans();

    /** The cnt text. */
    Text sex = new Text(" ");

    /** The state text. */
    Text age = new Text(" ");
    IntWritable amount = new IntWritable();


	public void map(LongWritable ikey, Text ivalue, Context context)
			throws IOException, InterruptedException {
		System.out.println("Mapping...");
		 String line = ivalue.toString();
         String[] keyvalue = line.split(",");
         System.out.println(Arrays.toString(keyvalue));
        /* if((keyvalue[7]!="" || keyvalue[7]!= null )|| (keyvalue[6]!="" || keyvalue[6]!= null ))
         {
        	 sex.set(new Text(keyvalue[7]));
         age.set(keyvalue[6]);
         System.out.println("Sex::__"+sex);
         System.out.println("Age::__"+age);
         }
         else {
        	 sex.set("");
             age.set("");
             System.out.println("Sex::"+sex);
             System.out.println("Age::"+age);
         }*/
         amount.set(Integer.parseInt(keyvalue[4]));
        
         RentTrans cntry = new RentTrans(sex, age);
         System.out.println("Amount::"+amount);
         
         context.write(cntry, amount);

	}

}
