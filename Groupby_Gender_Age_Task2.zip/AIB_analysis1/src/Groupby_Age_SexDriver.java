import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.io.WritableComparable;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
//import org.techmytalk.groupby.GroupMR.Country;
import org.apache.hadoop.util.GenericOptionsParser;


public class Groupby_Age_SexDriver {

	public static void main(String[] args) throws Exception {
		 Configuration conf = new Configuration();
         Job job = Job.getInstance(conf, "number of crimes");
        
         conf.set("fs.defaultFS", "hdfs://localhost:54310");
         conf.set("fs.hdfs.impl", org.apache.hadoop.hdfs.DistributedFileSystem.class.getName() );
         job.setJarByClass(Groupby_Age_SexDriver.class);
         // TODO: specify a mapper
         job.setMapperClass(GroupBy_Mapper.class);
         // TODO: specify a reducer
         job.setReducerClass(GroupBy_Reducer.class);

         // TODO: specify output types
         job.setMapOutputKeyClass(Text.class);
         job.setMapOutputValueClass(NullWritable.class);
      // TODO: specify input and output DIRECTORIES (not files)
         FileInputFormat.setInputPaths(job, new Path("hdfs://localhost:54310/user/hduser/RentTrans/output_join"));
         FileOutputFormat.setOutputPath(job, new Path("/user/hduser/RentTrans/output1"));

         if (!job.waitForCompletion(true))
             return;
	}

}
 class RentTrans implements WritableComparable<RentTrans> {

    Text sex_cde;
    Text age;

    public RentTrans(Text sex_cde, Text age) {
        this.sex_cde = sex_cde;
        this.age = age;
    }
    public RentTrans() {
        this.sex_cde = new Text();
        this.age = new Text();

    }

    /*
     * (non-Javadoc)
     * 
     * @see org.apache.hadoop.io.Writable#write(java.io.DataOutput)
     */
    public void write(DataOutput out) throws IOException {
        this.sex_cde.write(out);
        this.age.write(out);

    }

    /*
     * (non-Javadoc)
     * 
     * @see org.apache.hadoop.io.Writable#readFields(java.io.DataInput)
     */
    public void readFields(DataInput in) throws IOException {

        this.sex_cde.readFields(in);
        this.age.readFields(in);
        ;

    }

    /*
     * (non-Javadoc)
     * 
     * @see java.lang.Comparable#compareTo(java.lang.Object)
     */
    public int compareTo(RentTrans pop) {
        if (pop == null)
            return 0;
        int intcnt = sex_cde.compareTo(pop.sex_cde);
        if (intcnt != 0) {
            return intcnt;
        } else {
            return age.compareTo(pop.age);

        }
    }

    /*
     * (non-Javadoc)
     * 
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {

        return sex_cde.toString() + ":" + age.toString();
    }

}

